from gensim.models import Word2Vec, KeyedVectors
import pandas as pd 
import nltk

# sample data in the same folder 
df = pd.read_csv('redditNews.csv')

# look at the first 10 item  
# df.head(10)    

# we only want the titles from our data
newsTitle = df["title"].values

#tokenize each title in titles
newsVec = [nltk.word_tokenize(title) for title in newsTitle]

# build model 
model = Word2Vec(newsVec, min_count=1, size=32)

# show most similar word 
model.most_similar('boy')

# see individual word vec values 
model.wv['boy']

# sample:
# array([-1.9882004 , -3.015688  , -1.3027931 ,  4.5800867 , -0.01950181,
#         2.03641   ,  3.8108912 ,  0.685316  ,  2.9425657 , -0.77349144,
#         1.2414342 ,  1.6950755 ,  0.57560587, -3.5829062 , -4.370148  ,
#         1.0095215 ,  3.091991  , -4.2612734 , -0.62827826, -2.323164  ,
#        -3.6081884 ,  1.3765252 ,  0.2077533 , -1.2613134 , -3.9894698 ,
#        -0.330468  , -0.99500453, -1.741085  ,  2.0513268 ,  2.4484422 ,
#         2.614505  , -3.4637232 ], dtype=float32)
